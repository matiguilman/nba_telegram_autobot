QUICK START — NBA Telegram AutoBot

1) Requisitos
- Python 3.10+
- Crear un bot con @BotFather y copiar el token
- Agregar el bot como ADMIN en tu grupo/canal con permiso para "enviar mensajes" y "enviar medios"

2) Instalación
- Abrí esta carpeta en la consola (cmd) y corré:
  pip install -r requirements.txt
  copy .env.template .env
- Editá .env con tu TOKEN y @grupo/canal

3) Ejecutar
  python main.py

Listo: publica noticias con imagen + resumen y CTAs 3x/día con calendario e imagen 1080x1080.
